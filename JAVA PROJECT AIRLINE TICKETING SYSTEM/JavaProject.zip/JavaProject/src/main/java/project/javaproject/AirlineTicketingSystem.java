package project.javaproject;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

//The AirlineTicketingSystem class extends the Application class,
// which is the starting point of a JavaFX application.
// This class has two methods: main and start.
// The main method launches the JavaFX application by calling the launch method,
// passing AirlineTicketingSystem.class as an argument.

public class AirlineTicketingSystem extends Application {

    private List<Flight> flights = new ArrayList<>();


    //This code is the start() method that launches the main GUI window of the Airline Ticketing System.
    // It creates a Stage object named primaryStage and sets the title of the stage to "Airline Ticketing System".
    // It has a label with text "Welcome to the Airline Ticketing System" and two buttons
    // named "Admin" and "Passenger". The onAction event of the "Admin" button calls the
    // showAdminWindow() method, and the "Passenger" button calls the showPassengerWindow() method.
    // The labels and buttons are added to a vertical layout using a VBox. Finally, the scene is set
    // with the root node and dimensions and the stage is shown.
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Airline Ticketing System");

        Label label = new Label("Welcome to the Airline Ticketing System");

        Button btnAdmin = new Button("Admin");
        btnAdmin.setOnAction(event -> showAdminWindow());

        Button btnPassenger = new Button("Passenger");
        btnPassenger.setOnAction(event -> showPassengerWindow());

        VBox root = new VBox();
        root.getChildren().addAll(label, btnAdmin, btnPassenger);

        primaryStage.setScene(new Scene(root, 300, 250));
        primaryStage.show();
    }


    //This code creates a GUI window with the title "Admin" using JavaFX Stage and Scene.
    // It contains 3 text fields (flight number, origin, destination) and a "Add" button.
    // When the button is clicked, it creates a Flight object with the values entered in
    // the text fields, adds it to a list of flights, and clears the text fields.

    private void showAdminWindow() {
        Stage stage = new Stage();
        stage.setTitle("Admin");

        Label label = new Label("Add Flight");

        TextField flightNumber = new TextField();
        flightNumber.setPromptText("Flight Number");

        TextField origin = new TextField();
        origin.setPromptText("Origin");

        TextField destination = new TextField();
        destination.setPromptText("Destination");

        Button btnAdd = new Button("Add");
        btnAdd.setOnAction(event -> {
            Flight flight = new Flight(flightNumber.getText(), origin.getText(), destination.getText());
            flights.add(flight);
            flightNumber.clear();
            origin.clear();
            destination.clear();
        });

        VBox root = new VBox();
        root.getChildren().addAll(label, flightNumber, origin, destination, btnAdd);

        stage.setScene(new Scene(root, 300, 250));
        stage.show();
    }


    //This code creates a GUI window with the title "Passenger" using JavaFX Stage and Scene.
    //It contains a label displaying "Available Flights",
    // a list view showing the available flights, and a "Book" button.
    // When the button is clicked, it checks if a flight is selected from the list view,
    // removes it from the list of flights, removes it from the list view, and shows a
    // confirmation window with the booked flight information.
    private void showPassengerWindow() {
        Stage stage = new Stage();
        stage.setTitle("Passenger");

        Label label = new Label("Available Flights");

        ListView<Flight> flightListView = new ListView<>();
        flightListView.getItems().addAll(flights);

        Button btnBook = new Button("Book");
        btnBook.setOnAction(event -> {
            Flight selectedFlight = flightListView.getSelectionModel().getSelectedItem();
            if (selectedFlight != null) {
                flights.remove(selectedFlight);
                flightListView.getItems().remove(selectedFlight);
                showConfirmationWindow(selectedFlight);
            }
        });

        VBox root = new VBox();
        root.getChildren().addAll(label, flightListView, btnBook);

        stage.setScene(new Scene(root, 300, 250));
        stage.show();
    }

    //This code creates a GUI window with the title "Confirmation" using JavaFX Stage and Scene.
    // It contains a label displaying "Your flight has been booked" and a label displaying flight
    // details (by calling the toString() method of the flight object). The window displays
    // these labels in a vertical layout using a VBox. Finally, it sets the scene with the
    // root node and dimensions and shows the stage.
    private void showConfirmationWindow(Flight flight) {
        Stage stage = new Stage();
        stage.setTitle("Confirmation");

        Label label = new Label("Your flight has been booked");
        Label flightDetails = new Label(flight.toString());

        VBox root = new VBox();
        root.getChildren().addAll(label, flightDetails);

        stage.setScene(new Scene(root, 300, 250));
        stage.show();
    }

    //This code defines a Flight class that has three private fields:
    // flightNumber, origin, and destination.
    // The class provides a constructor to initialize these fields with values passed as arguments.
    // The class is declared as static which means it is a nested class within the enclosing class
    // and can be accessed without creating an instance of the enclosing class.

    private static class Flight {
        private final String flightNumber;
        private final String origin;
        private final String destination;

        public Flight(String flightNumber, String origin, String destination) {
            this.flightNumber = flightNumber;
            this.origin = origin;
            this.destination = destination;
        }



        //This code is a method in the Flight class that overrides the toString()
        // method from the parent class (Object class). The toString() method returns
        // a string representation of the Flight object in the format: "Flight{flightNumber='<flightNumber>',
        // origin='<origin>', destination='<destination>'}" where <flightNumber>, <origin>,
        // and <destination> are the values of the respective fields of the Flight object.


        @Override
        public String toString() {
            return "Flight{" +
                    "flightNumber='" + flightNumber + '\'' +
                    ", origin='" + origin + '\'' +
                    ", destination='" + destination + '\'' +
                    '}';
        }
    }




    //the first method to run when the application is executed.
    public static void main(String[] args) {
        launch();
    }
}