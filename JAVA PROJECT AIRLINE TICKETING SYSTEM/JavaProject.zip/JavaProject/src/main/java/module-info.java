module project.javaproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens project.javaproject to javafx.fxml;
    exports project.javaproject;
}